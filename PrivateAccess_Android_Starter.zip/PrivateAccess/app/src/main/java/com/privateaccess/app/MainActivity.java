package com.privateaccess.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.security.SecureRandom;

public class MainActivity extends Activity {
    private static final int REQUEST_SCREEN_CAPTURE = 4101;
    private TextView status;
    private TextView codeView;
    private boolean permissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24), dp(36), dp(24), dp(24));
        page.setBackgroundColor(Color.rgb(12, 20, 36));

        TextView title = new TextView(this);
        title.setText("PRIVATE ACCESS");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Consent-first Android remote support");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, dp(28));
        page.addView(subtitle, matchWrap());

        TextView pairingLabel = new TextView(this);
        pairingLabel.setText("YOUR DEMO PAIRING CODE");
        pairingLabel.setTextColor(Color.rgb(166, 190, 225));
        pairingLabel.setTextSize(12);
        pairingLabel.setGravity(Gravity.CENTER);
        page.addView(pairingLabel, matchWrap());

        codeView = new TextView(this);
        codeView.setText(makeCode());
        codeView.setTextColor(Color.WHITE);
        codeView.setTextSize(30);
        codeView.setTypeface(null, 1);
        codeView.setGravity(Gravity.CENTER);
        codeView.setPadding(0, dp(10), 0, dp(20));
        page.addView(codeView, matchWrap());

        status = new TextView(this);
        status.setText("Screen sharing is OFF. No one can view this phone.");
        status.setTextColor(Color.WHITE);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(12), dp(18), dp(12), dp(18));
        status.setBackgroundColor(Color.rgb(29, 43, 66));
        page.addView(status, matchWrap());

        Button consent = new Button(this);
        consent.setText("Review screen-sharing permission");
        consent.setAllCaps(false);
        LinearLayout.LayoutParams bp = matchWrap();
        bp.topMargin = dp(24);
        page.addView(consent, bp);
        consent.setOnClickListener(v -> requestScreenPermission());

        Button stop = new Button(this);
        stop.setText("Reset permission status");
        stop.setAllCaps(false);
        LinearLayout.LayoutParams sp = matchWrap();
        sp.topMargin = dp(10);
        page.addView(stop, sp);
        stop.setOnClickListener(v -> {
            permissionGranted = false;
            status.setText("Screen sharing is OFF. No one can view this phone.");
        });

        TextView note = new TextView(this);
        note.setText("DEMO BUILD\nThe pairing code is local-only. Remote viewing, file transfer, camera/microphone streaming and admin accounts are not connected yet. Android will show its own consent prompt before screen capture.");
        note.setTextColor(Color.rgb(185, 198, 218));
        note.setTextSize(13);
        note.setPadding(0, dp(24), 0, 0);
        page.addView(note, matchWrap());

        setContentView(page);
    }

    private void requestScreenPermission() {
        MediaProjectionManager manager =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            permissionGranted = (resultCode == Activity.RESULT_OK && data != null);
            if (permissionGranted) {
                status.setText("Android screen-sharing permission granted for this session. Remote connection is not active.");
            } else {
                status.setText("Permission not granted. Screen sharing remains OFF.");
            }
        }
    }

    private String makeCode() {
        SecureRandom random = new SecureRandom();
        int number = 100000 + random.nextInt(900000);
        return String.valueOf(number);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
