# Private Access — Android MVP starter

এটি Private Access-এর প্রথম Android Studio starter project।

## এই build-এ যা কাজ করে
- Private Access-এর প্রাথমিক Android UI
- একটি local demo pairing code
- Android-এর নিজস্ব MediaProjection consent prompt খোলা
- ব্যবহারকারী অনুমতি দিলে সেই সেশনের permission result দেখানো
- অনুমতি না দিলে screen sharing OFF দেখানো

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনো সম্পূর্ণ remote-access app নয়। Pairing code শুধু এই ফোনে তৈরি হয়; কোনো সার্ভারে যাচাই হয় না। অন্য ফোন থেকে লাইভ স্ক্রিন দেখা, remote input/control, file transfer, camera/microphone streaming, login/database এবং admin dashboard এখনো যোগ করা হয়নি। এগুলো তৈরি করতে authenticated backend, secure signaling এবং WebRTC যোগ করতে হবে। এই starter নিজে থেকে স্ক্রিন রেকর্ড বা সম্প্রচার করে না।

## APK তৈরি
1. Android Studio-তে `PrivateAccess` ফোল্ডারটি Open করুন।
2. Gradle sync সম্পন্ন হতে দিন (Android SDK 35 এবং JDK 17 প্রয়োজন)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
4. Debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যাবে।

এই পরিবেশে Android SDK/Gradle build tool নেই, তাই এখানে সরাসরি ইনস্টলযোগ্য APK compile করা হয়নি।
